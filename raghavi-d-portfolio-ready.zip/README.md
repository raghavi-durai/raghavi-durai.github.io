# Raghavi D — Portfolio

This folder contains the portfolio website and a PDF copy of the resume supplied for the portfolio.

## Publish for free using GitHub Pages

1. Sign in to GitHub.
2. Create a **public** repository. A repository named `raghavi-durai.github.io` can give a clean user-site URL.
3. Upload `index.html`, `style.css`, and `resume.pdf`.
4. Go to **Settings → Pages**.
5. Under deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site.

The LinkedIn and GitHub links in the website have already been filled from the supplied resume.
